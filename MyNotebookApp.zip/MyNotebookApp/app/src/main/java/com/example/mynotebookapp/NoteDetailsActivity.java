package com.example.mynotebookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mynotebookapp.model.Not;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NoteDetailsActivity extends AppCompatActivity {

    public static final String EXTRA_NOTE_TYPE = "EXTRA_NOTE_TYPE";
    public static final boolean NOTE_TYPE_NEW = true;

    boolean isNewNote; // boolean olarak tanımlandı
    EditText inputTitle, inputNote;
    TextView textDate;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);

        db = new Database(this);

        isNewNote = getIntent().getBooleanExtra(EXTRA_NOTE_TYPE, false); // boolean olarak değiştirildi

        inputTitle = findViewById(R.id.inputTitle);
        inputNote = findViewById(R.id.inputNote);
        textDate = findViewById(R.id.textDate);

        String pattern = "EEEE, dd MMMM yyyy HH:mm";
        textDate.setText(new SimpleDateFormat(pattern, Locale.getDefault()).format(new Date()));

        findViewById(R.id.imageSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputTitle.getText().toString().trim().isEmpty()) {
                    inputTitle.setError("Başlık Giriniz");
                } else if (inputNote.getText().toString().trim().isEmpty()) {
                    inputNote.setError("Lütfen Not Giriniz");
                } else {
                    // Insert a new note into the database
                    db.YeniNot(new Not(
                            inputTitle.getText().toString(),
                            inputNote.getText().toString(),
                            null, // webUrl
                            null, // imageUrl
                            textDate.getText().toString(),
                            null // renk
                    ));

                    // Perform any additional database operations if needed
                    if (isNewNote) {
                        // Eğer yeni not ekleniyorsa, MainActivity'i güncelle
                        MainActivity mainActivity = new MainActivity();
                        db.updateNoteList(mainActivity);
                    }

                    finish();
                }
            }
        });

        findViewById(R.id.imageBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
