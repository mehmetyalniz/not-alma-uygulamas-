package com.example.mynotebookapp;

import com.example.mynotebookapp.model.Not;

public interface NoteListener {
    void noteClick(Not not);

    void NoteClick(Not not);
}
