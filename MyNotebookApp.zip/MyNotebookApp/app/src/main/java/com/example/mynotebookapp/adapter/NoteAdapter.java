package com.example.mynotebookapp.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mynotebookapp.NoteListener;
import com.example.mynotebookapp.R;
import com.example.mynotebookapp.model.Not;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private final ArrayList<Not> notListesi;
    private final NoteListener listener;

    public NoteAdapter(ArrayList<Not> notListesi, Activity activity) {
        this.notListesi = notListesi;
        this.listener = (NoteListener) activity;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NoteViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_note, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        holder.setNote(notListesi.get(position));
    }

    @Override
    public int getItemCount() {
        return notListesi.size();
    }

    public void updateNoteList() {
    }

    class NoteViewHolder extends RecyclerView.ViewHolder {

        CardView cardViewContainer;
        TextView textTitle, textNote, textDate;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            cardViewContainer = itemView.findViewById(R.id.cardViewContainer);
            textTitle = itemView.findViewById(R.id.textTitle);
            textNote = itemView.findViewById(R.id.textNote);
            textDate = itemView.findViewById(R.id.textDate);
        }

        void setNote(Not not) {
            textTitle.setText(not.getBaslik());
            textNote.setText(not.getNotMetin());
            textDate.setText(not.getTarih());
            cardViewContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.noteClick(not);
                }
            });
        }
    }
}
