package com.example.mynotebookapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mynotebookapp.model.Not;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "NoteDatabase";
    private static final int DATABASE_VERSION = 1;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Notlar tablosunu oluşturmak için gerekli SQL sorgusu
        String CREATE_NOTLAR_TABLE = "CREATE TABLE Notlar (id INTEGER PRIMARY KEY, baslik TEXT, notMetin TEXT, webUrl TEXT, imageUrl TEXT, color TEXT, tarih TEXT)";
        db.execSQL(CREATE_NOTLAR_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Veritabanı versiyonu değişirse burada gerekli güncelleme işlemleri yapılabilir.
    }

    public ArrayList<Not> getNotlarim() {
        SQLiteDatabase db = this.getReadableDatabase();
        String SELECT_NOTLAR = "SELECT * FROM Notlar ORDER BY id DESC";

        Cursor cursor = db.rawQuery(SELECT_NOTLAR, null);
        ArrayList<Not> notlar = new ArrayList<>();

        try {
            int idColumnIndex = cursor.getColumnIndex("id");
            int baslikColumnIndex = cursor.getColumnIndex("baslik");
            int notMetinColumnIndex = cursor.getColumnIndex("notMetin");
            int webUrlColumnIndex = cursor.getColumnIndex("webUrl");
            int imageUrlColumnIndex = cursor.getColumnIndex("imageUrl");
            int colorColumnIndex = cursor.getColumnIndex("color");
            int tarihColumnIndex = cursor.getColumnIndex("tarih");

            while (cursor.moveToNext()) {
                Not not = new Not();
                not.setId(cursor.getInt(idColumnIndex));
                not.setBaslik(cursor.getString(baslikColumnIndex));
                not.setNotMetin(cursor.getString(notMetinColumnIndex));
                not.setWebUrl(cursor.getString(webUrlColumnIndex));
                not.setImageUrl(cursor.getString(imageUrlColumnIndex));
                not.setRenk(cursor.getString(colorColumnIndex));
                not.setTarih(cursor.getString(tarihColumnIndex));
                notlar.add(not);
            }
        } finally {
            cursor.close();
        }

        return notlar;
    }

    public void YeniNot(Not not) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("baslik", not.getBaslik());
        values.put("notMetin", not.getNotMetin());
        values.put("webUrl", not.getWebUrl());
        values.put("imageUrl", not.getImageUrl());
        values.put("color", not.getRenk());
        values.put("tarih", not.getTarih());

        db.insert("Notlar", null, values);

        // Close the database to free up resources
        db.close();

        // Eklenen notu göstermek için MainActivity'de bulunan updateNoteListStatic metodu çağrılır
        MainActivity.updateNoteListStatic();
    }


    public void updateNoteList(MainActivity mainActivity) {

    }
}
