
package com.example.mynotebookapp;

        import androidx.appcompat.app.AppCompatActivity;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;
        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.ImageView;
        import com.example.mynotebookapp.adapter.NoteAdapter;
        import com.example.mynotebookapp.model.Not;
        import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NoteListener {
    private ImageView imageAddNote;
    private Database db;
    private NoteAdapter adapter;
    private RecyclerView recyclerView;
    private ArrayList<Not> noteList;

    public static void updateNoteListStatic() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

    private void initialize() {
        db = new Database(this);
        noteList = new ArrayList<>();
        imageAddNote = findViewById(R.id.imageAddNote);
        recyclerView = findViewById(R.id.recylerviewNotlar);

        noteList.addAll(db.getNotlarim());
        adapter = new NoteAdapter(noteList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        imageAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NoteDetailsActivity.class);
                intent.putExtra(NoteDetailsActivity.EXTRA_NOTE_TYPE, NoteDetailsActivity.NOTE_TYPE_NEW);
                startActivityForResult(intent, REQUEST_CODE_NEW_NOTE);
            }
        });


    }

    private void updateNoteList() {
        noteList.clear();
        noteList.addAll(db.getNotlarim());
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateNoteList();
    }

    @Override
    public void noteClick(Not note) {
        // Handle note click action if needed
    }

    @Override
    public void NoteClick(Not not) {
        // Implement NoteClick method if needed
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_NEW_NOTE && resultCode == RESULT_OK) {
            updateNoteList();
        }
    }

    private static final int REQUEST_CODE_NEW_NOTE = 1;
}